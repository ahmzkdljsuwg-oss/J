/**
 * ROZLF Cloudflare Worker — Backend
 * يخفي مفاتيح API ويجلب:
 *   - أسعار فوركس حقيقية من exchangerate-api (مجاني)
 *   - تحليل Claude AI
 * نشر: wrangler deploy
 */

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...CORS },
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // OPTIONS preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: CORS });
    }

    // ── GET /prices ──────────────────────────────────────────────
    // مصدر مجاني: frankfurter.app (بيانات ECB حقيقية، بدون مفتاح)
    if (url.pathname === '/prices') {
      try {
        const pairs = ['EUR','GBP','AUD','NZD','CAD','CHF','JPY'];
        const r = await fetch(
          `https://api.frankfurter.app/latest?from=USD&to=${pairs.join(',')}`
        );
        const d = await r.json();
        // فرنكفورتر يعطي: d.rates = { EUR: 0.92, ... }
        const prices = {};
        const rates = d.rates;
        // EURUSD = 1/rates.EUR
        prices['EURUSD'] = +(1 / rates.EUR).toFixed(5);
        prices['GBPUSD'] = +(1 / rates.GBP).toFixed(5);
        prices['AUDUSD'] = +(1 / rates.AUD).toFixed(5);
        prices['NZDUSD'] = +(1 / rates.NZD).toFixed(5);
        prices['USDCAD'] = +rates.CAD.toFixed(5);
        prices['USDCHF'] = +rates.CHF.toFixed(5);
        prices['USDJPY'] = +rates.JPY.toFixed(3);
        // XAU/USD من metals-api مجاني (أو fallback ثابت)
        try {
          const gold = await fetch('https://api.metals.live/v1/spot/gold');
          const gd = await gold.json();
          prices['XAUUSD'] = +(gd[0]?.price || 1980).toFixed(2);
        } catch {
          prices['XAUUSD'] = 1982.50; // fallback
        }
        return json({ ok: true, prices, source: 'frankfurter.app + metals.live', ts: Date.now() });
      } catch (e) {
        return json({ ok: false, error: e.message }, 500);
      }
    }

    // ── GET /history?pair=EURUSD&tf=M15 ──────────────────────────
    // بيانات OHLC حقيقية من stooq.com (مجاني بدون مفتاح)
    if (url.pathname === '/history') {
      const pair = url.searchParams.get('pair') || 'EURUSD';
      const tf   = url.searchParams.get('tf') || 'M15';
      try {
        // stooq رموز: EURUSD → eurusd
        const sym = pair.toLowerCase();
        // stooq interval: 5 = 5min, 60 = hourly, d = daily
        const intervalMap = { M1:'1',M5:'5',M15:'15',H1:'60',H4:'240',D1:'d' };
        const iv = intervalMap[tf] || '15';
        const stooqUrl = iv === 'd'
          ? `https://stooq.com/q/d/l/?s=${sym}&i=d`
          : `https://stooq.com/q/i/l/?s=${sym}&i=${iv}`;
        const r = await fetch(stooqUrl, { headers: { 'User-Agent': 'ROZLF/1.0' } });
        const csv = await r.text();
        const lines = csv.trim().split('\n').slice(1); // skip header
        const candles = lines.slice(-80).map(line => {
          const [date, open, high, low, close, vol] = line.split(',');
          return {
            t: date,
            o: +parseFloat(open).toFixed(5),
            h: +parseFloat(high).toFixed(5),
            l: +parseFloat(low).toFixed(5),
            c: +parseFloat(close).toFixed(5),
            v: +vol || 0,
          };
        }).filter(c => c.c > 0);
        if (candles.length < 5) throw new Error('no data');
        return json({ ok: true, pair, tf, candles });
      } catch (e) {
        return json({ ok: false, error: 'stooq unavailable: ' + e.message }, 503);
      }
    }

    // ── POST /analyze ─────────────────────────────────────────────
    // Claude AI — المفتاح مخفي في Worker env
    if (url.pathname === '/analyze' && request.method === 'POST') {
      const body = await request.json().catch(() => ({}));
      const { pair, price, rsi, macd, bb, stoch, ma50, direction } = body;

      const prompt = `أنت محلل فوركس خبير ومتخصص. قدّم تحليلاً احترافياً مختصراً لزوج ${pair} باللغة العربية بناءً على البيانات الحقيقية التالية:

📊 البيانات الفنية:
- السعر الحالي: ${price}
- RSI (14): ${rsi}
- MACD: ${macd}
- Bollinger Bands موقع السعر: ${bb}
- Stochastic: ${stoch}
- MA50: ${ma50}
- الاتجاه العام: ${direction}

اكتب التحليل بهذا الترتيب:
1. **التحليل الفني** (3-4 سطور واضحة)
2. **مستويات الدعم والمقاومة** (أرقام محددة)
3. **الإشارة الموصى بها**: شراء / بيع / انتظار — مع سبب واحد مختصر
4. **نقطة الدخول** و**هدف الربح** و**وقف الخسارة** (بالأرقام)
5. **تحذير المخاطرة** (جملة واحدة)

كن دقيقاً، الأرقام محددة، لا تعطِ نصائح عامة.`;

      try {
        const r = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': env.ANTHROPIC_KEY,         // مخفي في Worker secrets
            'anthropic-version': '2023-06-01',
          },
          body: JSON.stringify({
            model: 'claude-sonnet-4-6',
            max_tokens: 1000,
            messages: [{ role: 'user', content: prompt }],
          }),
        });
        const d = await r.json();
        if (d.error) throw new Error(d.error.message);
        const text = d.content?.map(b => b.text || '').join('\n') || '';
        return json({ ok: true, analysis: text });
      } catch (e) {
        return json({ ok: false, error: e.message }, 500);
      }
    }

    return json({ ok: false, error: 'not found' }, 404);
  },
};
