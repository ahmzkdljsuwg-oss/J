# ROZLF — Forex AI App

## هيكل المشروع

```
rozlf/
├── frontend/          ← PWA (Cloudflare Pages)
│   └── index.html
├── worker/            ← Backend (Cloudflare Worker)
│   ├── index.js
│   └── wrangler.toml
├── capacitor-config/  ← إعداد IPA
│   └── capacitor.config.json
└── README.md
```

---

## 1. نشر Worker على Cloudflare (مجاناً)

```bash
# تثبيت wrangler
npm install -g wrangler

# تسجيل دخول
wrangler login

# انتقل للمجلد
cd worker

# أضف مفتاح Claude مخفياً (لن يظهر في الكود)
wrangler secret put ANTHROPIC_KEY
# أدخل مفتاحك حين يطلبه

# انشر
wrangler deploy
```
ستحصل على رابط مثل: `https://rozlf-backend.YOUR-NAME.workers.dev`

---

## 2. نشر Frontend على Cloudflare Pages (مجاناً)

```bash
# من Cloudflare Dashboard → Pages → Create Project
# ارفع مجلد frontend/ مباشرة
# أو عبر CLI:
npx wrangler pages deploy frontend/ --project-name=rozlf
```
ستحصل على رابط مثل: `https://rozlf.pages.dev`

---

## 3. ربط Frontend بـ Worker

افتح التطبيق ← إعدادات ← الصق رابط Worker ← أطفئ "وضع Demo"

---

## 4. بناء IPA للـ iPhone (ESign)

### المتطلبات:
- Node.js 18+
- Xcode (Mac)
- CocoaPods

```bash
# في مجلد المشروع الرئيسي
npm init -y
npm install @capacitor/core @capacitor/ios @capacitor/cli

# انسخ إعداد Capacitor
cp capacitor-config/capacitor.config.json .

# أضف iOS
npx cap add ios

# انسخ ملفات الـ web
npx cap sync ios

# افتح Xcode
npx cap open ios
```

### في Xcode:
1. اختر Target: `App`
2. Signing & Capabilities → أضف Apple ID مجاني
3. Product → Archive
4. Distribute → Ad Hoc أو Development
5. ستحصل على ملف `.ipa`

### تثبيت عبر ESign:
1. ارفع الـ `.ipa` على أي خادم أو Google Drive
2. افتح ESign على iPhone
3. Import → الصق الرابط أو استخدم AirDrop
4. ثبّت وامنح الثقة من الإعدادات

---

## الميزات الحقيقية

| الميزة | المصدر |
|--------|--------|
| أسعار الفوركس | Frankfurter.app (ECB) — مجاني |
| تحليل AI | Claude claude-sonnet-4-6 عبر Worker |
| مفاتيح API | مخفية في Worker secrets |
| RSI/MACD/BB/Stoch | محسوبة من OHLC فعلي |
| الاستضافة | Cloudflare Pages + Workers — مجاني |

---

## المصادر المجانية المستخدمة

- **Frankfurter.app** — أسعار ECB الرسمية بدون مفتاح
- **metals.live** — أسعار الذهب
- **stooq.com** — OHLC تاريخي (عبر Worker)
- **Cloudflare Workers** — 100,000 طلب/يوم مجاناً
- **Cloudflare Pages** — استضافة مجانية غير محدودة
